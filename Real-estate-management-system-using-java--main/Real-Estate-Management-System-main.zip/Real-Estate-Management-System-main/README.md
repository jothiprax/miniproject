# Real-Estate-Management-System
Fully functional real estate management system implemented using Java, JavaFX, MySQL and SceneBuilder.
