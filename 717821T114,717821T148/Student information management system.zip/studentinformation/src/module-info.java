/**
 * 
 */
/**
 * @author johnp
 *
 */
module studentinformation {
	requires java.sql;
}