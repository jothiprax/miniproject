


	package com.kce.util;

	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.SQLException;

	public class DBUtil {
	    private static final String URL = "jdbc:mysql://localhost:3306/student_db";
	    private static final String USERNAME = "root";
	    private static final String PASSWORD = "jesus";

	    public static Connection getConnection() {
	        Connection connection = null;
	        try {
	            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return connection;
	    }
	}



