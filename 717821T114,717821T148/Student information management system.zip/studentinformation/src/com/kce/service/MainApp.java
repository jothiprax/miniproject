package com.kce.service;

import com.kce.bean.Student;
import com.kce.dao.StudentDAO;

import java.util.List;
import java.util.Scanner;

public class MainApp {
    private static final Scanner scanner = new Scanner(System.in);
    private static final StudentDAO studentDAO = new StudentDAO();

    public static void main(String[] args) {
        while (true) {
            System.out.println("Student Information Management System");
            System.out.println("1. Add Student");
            System.out.println("2. Update Student");
            System.out.println("3. Delete Student");
            System.out.println("4. View All Students");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    addStudent();
                    break;

                case 2:
                    updateStudent();
                    break;

                case 3:
                    deleteStudent();
                    break;

                case 4:
                    viewAllStudents();
                    break;

                case 5:
                    System.out.println("Thank you. Exiting...");
                    System.exit(0);

                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }
    }

    private static void addStudent() {
    	 System.out.print("Enter student id: ");
         int id = Integer.parseInt(scanner.nextLine());
        System.out.print("Enter student name: ");
        String name = scanner.nextLine();
        System.out.print("Enter student age: ");
        int age = Integer.parseInt(scanner.nextLine());
        System.out.print("Enter student address: ");
        String address = scanner.nextLine();

        Student student = new Student(id, name, age, address);
        studentDAO.addStudent(student);
        System.out.println("Student added successfully.");
        System.out.println();
    }

    private static void updateStudent() {
        System.out.print("Enter student ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        Student student = studentDAO.getStudentById(id);
        if (student != null) {
            System.out.print("Enter new name: ");
            String name = scanner.nextLine();
            System.out.print("Enter new age: ");
            int age = scanner.nextInt();
            scanner.nextLine();
            System.out.print("Enter new address: ");
            String address = scanner.nextLine();

            student.setName(name);
            student.setAge(age);
            student.setAddress(address);

            studentDAO.updateStudent(student);
            System.out.println("Student updated successfully.");
        } else {
            System.out.println("Student not found.");
        }
        System.out.println();
    }

    private static void deleteStudent() {
        System.out.print("Enter student ID: ");
        int id = scanner.nextInt();
     
        Student student = studentDAO.getStudentById(id);
        if (student != null) {
            studentDAO.deleteStudent(id);
            System.out.println("Student deleted successfully.");
        } else {
            System.out.println("Student not found.");
        }
        System.out.println();
    }

    private static void viewAllStudents() {
        List<Student> students = studentDAO.getAllStudents();
        if (!students.isEmpty()) {
            System.out.println("All Students:");
            for (Student student : students) {
                System.out.println(student);
            }
        } else {
            System.out.println("No students found.");
        }
        System.out.println();
    }
}
