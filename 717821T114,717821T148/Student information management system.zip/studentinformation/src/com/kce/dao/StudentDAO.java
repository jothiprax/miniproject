

	package com.kce.dao;

	import com.kce.bean.Student;
	import com.kce.util.DBUtil;

	import java.sql.Connection;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.util.ArrayList;
	import java.util.List;

	public class StudentDAO {
	    private static final String INSERT_QUERY = "INSERT INTO students (id,name, age, address) VALUES (?,?, ?, ?)";
	    private static final String UPDATE_QUERY = "UPDATE students SET name=?, age=?, address=? WHERE id=?";
	    private static final String DELETE_QUERY = "DELETE FROM students WHERE id=?";
	    private static final String SELECT_ALL_QUERY = "SELECT * FROM students";
	    private static final String SELECT_BY_ID_QUERY = "SELECT * FROM students WHERE id=?";

	    public void addStudent(Student student) {
	        try (Connection connection = DBUtil.getConnection();
	             PreparedStatement statement = connection.prepareStatement(INSERT_QUERY)) {
	        	statement.setInt(1, student.getId());
	            statement.setString(2, student.getName());
	            statement.setInt(3, student.getAge());
	            statement.setString(4, student.getAddress());
	            statement.executeUpdate();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    public void updateStudent(Student student) {
	        try (Connection connection = DBUtil.getConnection();
	             PreparedStatement statement = connection.prepareStatement(UPDATE_QUERY)) {
	            statement.setString(1, student.getName());
	            statement.setInt(2, student.getAge());
	            statement.setString(3, student.getAddress());
	            statement.setInt(4, student.getId());
	            statement.executeUpdate();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    public void deleteStudent(int id) {
	        try (Connection connection = DBUtil.getConnection();
	             PreparedStatement statement = connection.prepareStatement(DELETE_QUERY)) {
	            statement.setInt(1, id);
	            statement.executeUpdate();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    public List<Student> getAllStudents() {
	        List<Student> students = new ArrayList<>();
	        try (Connection connection = DBUtil.getConnection();
	             PreparedStatement statement = connection.prepareStatement(SELECT_ALL_QUERY);
	             ResultSet resultSet = statement.executeQuery()) {
	            while (resultSet.next()) {
	                int id = resultSet.getInt("id");
	                String name = resultSet.getString("name");
	                int age = resultSet.getInt("age");
	                String address = resultSet.getString("address");
	                students.add(new Student(id, name, age, address));
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return students;
	    }

	    public Student getStudentById(int id) {
	        Student student = null;
	        try (Connection connection = DBUtil.getConnection();
	             PreparedStatement statement = connection.prepareStatement(SELECT_BY_ID_QUERY)) {
	           
	            try (ResultSet resultSet = statement.executeQuery()) {
	                if (resultSet.next()) {
	                	 statement.setInt(1, id);
	                    String name = resultSet.getString("name");
	                    int age = resultSet.getInt("age");
	                    String address = resultSet.getString("address");
	                    student = new Student(id, name, age, address);
	                }
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return student;
	    }
	}



